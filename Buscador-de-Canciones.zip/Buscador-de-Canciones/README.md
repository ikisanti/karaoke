# Buscador-de-Canciones-con-API
Hacemos un buscador de Letras de Canciones usando el API de "lyrics.ovh".

**Tutorial**
<br/><br/>
https://youtu.be/zX_QwqSUmpQ
<br/><br/>
**Demo**

![image](https://drive.google.com/uc?export=view&id=1qiE6Mb3-rW40sLywJ77kBcUWNUCczuT1)
